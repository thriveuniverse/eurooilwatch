#!/usr/bin/env npx tsx
/**
 * EuroOilWatch — EC Weekly Oil Bulletin Price Fetcher
 * ====================================================
 * Pulls weekly fuel prices from the European Commission's Oil Bulletin.
 *
 * The EC publishes weekly consumer prices for petroleum products every Thursday.
 * Data source: https://energy.ec.europa.eu/data-and-analysis/weekly-oil-bulletin_en
 *
 * Strategy:
 * 1. Try the Eurostat API for fuel prices (sts_iipp_m or nrg_pc_204)
 * 2. Fallback: scrape the Oil Bulletin page for CSV/XLS download links
 * 3. Parse and normalise to EUR/litre for petrol (Euro-super-95) and diesel
 *
 * Usage: npx tsx scripts/fetch-oil-bulletin.ts
 * Output: data/prices.json
 */

import * as fs from 'fs';
import * as path from 'path';
import {
  CountryPriceData,
  PriceDataset,
  CountryCode,
} from '../lib/types';
import { COUNTRIES, EU27_CODES } from '../lib/countries';

const OUTPUT_FILE = path.join(__dirname, '..', 'data', 'prices.json');

/**
 * The EC Oil Bulletin data is also available via the Eurostat API as
 * dataset 'nrg_pc_204' (fuel prices for consumers) or through the
 * DG Energy Oil Bulletin API wrapper.
 *
 * Endpoint for Oil Bulletin weekly data (CSV):
 * This URL pattern may change — the test script validates it.
 */
const OIL_BULLETIN_API = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nrg_pc_204';

/**
 * Alternative: the Apitalks wrapper for the Oil Bulletin
 * https://api.store/eu-institutions-api/directorate-general-for-energy-api
 * This is free and returns the bulletin data as JSON.
 */

// Fuel price Eurostat codes
// nrg_pc_204: Energy prices — oil products
// product = 4652 (Euro-super-95) or 4671 (gas oil / diesel)
// unit = EUR_LTR (EUR per litre)
// tax = TAX (with all taxes) or X_TAX (without taxes)
// consumer = HOUSEHOLD (consumers)

async function fetchEurostatPrices(): Promise<PriceDataset | null> {
  console.log('📊 Attempting Eurostat price data (nrg_pc_204)...');

  // Eurostat oil product prices — semi-annual, not weekly
  // For weekly data, we need the Oil Bulletin directly
  // Let's try the weekly bulletin approach instead

  const geoCodes = EU27_CODES.map(c => COUNTRIES[c].eurostatCode);

  try {
    const url = new URL(OIL_BULLETIN_API);
    url.searchParams.set('format', 'JSON');
    url.searchParams.set('lang', 'en');
    url.searchParams.set('lastTimePeriod', '2');
    // Add product and tax filters
    geoCodes.forEach(g => url.searchParams.append('geo', g));

    const response = await fetch(url.toString(), {
      headers: { 'User-Agent': 'EuroOilWatch/0.1 (data-pipeline)' },
    });

    if (!response.ok) {
      console.log(`  ⚠️ Eurostat returned ${response.status} — trying alternative source`);
      return null;
    }

    const data = await response.json();
    console.log(`  ✅ Got Eurostat price data`);
    // Parse the response... (similar to stock parser)
    // This would need dataset-specific parsing
    return null; // TODO: implement full parsing once API response format is confirmed
  } catch (err: any) {
    console.log(`  ⚠️ Eurostat prices unavailable: ${err.message}`);
    return null;
  }
}

/**
 * Alternative: fetch from the fuel-prices.eu API or parse the EC bulletin directly.
 *
 * For the MVP, we'll use a direct approach:
 * 1. Download the Oil Bulletin CSV from the EC website
 * 2. Parse it for the latest week's data
 *
 * The Oil Bulletin CSV URL pattern (may need updating):
 * https://energy.ec.europa.eu/system/files/documents/...
 */
async function fetchOilBulletinDirect(): Promise<PriceDataset | null> {
  console.log('📰 Fetching EC Oil Bulletin directly...');

  // The Oil Bulletin page contains links to the latest data
  // We need to scrape the page to find the current CSV/XLS link
  try {
    const pageResponse = await fetch(
      'https://energy.ec.europa.eu/data-and-analysis/weekly-oil-bulletin_en',
      { headers: { 'User-Agent': 'EuroOilWatch/0.1 (data-pipeline)' } }
    );

    if (!pageResponse.ok) {
      console.log(`  ⚠️ Oil Bulletin page returned ${pageResponse.status}`);
      return null;
    }

    const html = await pageResponse.text();

    // Look for CSV or XLS download links
    const csvMatch = html.match(/href="([^"]*(?:csv|xls|xlsx)[^"]*)"/gi);
    if (csvMatch) {
      console.log(`  Found ${csvMatch.length} data file links`);
      // Try to fetch the first CSV/XLS file
      for (const match of csvMatch) {
        const urlStr = match.replace(/href="/i, '').replace(/"$/, '');
        const dataUrl = urlStr.startsWith('http') ? urlStr : `https://energy.ec.europa.eu${urlStr}`;
        console.log(`  Trying: ${dataUrl.substring(0, 80)}...`);

        try {
          const dataResponse = await fetch(dataUrl, {
            headers: { 'User-Agent': 'EuroOilWatch/0.1 (data-pipeline)' },
          });
          if (dataResponse.ok) {
            const text = await dataResponse.text();
            console.log(`  ✅ Downloaded ${(text.length / 1024).toFixed(1)} KB`);
            // Parse the CSV data here
            // This is where the real parsing logic would go
            return parseOilBulletinCSV(text);
          }
        } catch {
          continue;
        }
      }
    }

    console.log('  ⚠️ No parseable data files found on Oil Bulletin page');
    return null;
  } catch (err: any) {
    console.log(`  ⚠️ Oil Bulletin fetch failed: ${err.message}`);
    return null;
  }
}

/**
 * Parse the Oil Bulletin CSV data into our standard format.
 * The CSV format varies, but typically contains:
 * Country, Date, Euro-super 95 with taxes (EUR/1000L), Diesel with taxes (EUR/1000L)
 */
function parseOilBulletinCSV(csvText: string): PriceDataset | null {
  console.log('  Parsing Oil Bulletin CSV...');

  // Split into lines and find header
  const lines = csvText.split('\n').filter(l => l.trim());
  if (lines.length < 2) return null;

  // The format varies — log the first few lines so we can debug
  console.log('  First 3 lines of data:');
  lines.slice(0, 3).forEach((l, i) => console.log(`    [${i}] ${l.substring(0, 100)}`));

  // TODO: Implement full CSV parsing based on actual format
  // This will be refined once you run the test script and see the actual data

  return null;
}

/**
 * If live data isn't available, use seed data so the dashboard works.
 * This gets replaced once the pipeline is running.
 */
function generateSeedPrices(): PriceDataset {
  console.log('🌱 Generating seed price data for development...');

  // Approximate prices as of March 2026 (based on EC Oil Bulletin)
  const seedPrices: Record<CountryCode, { petrol: number; diesel: number }> = {
    AT: { petrol: 1.65, diesel: 1.78 },
    BE: { petrol: 1.88, diesel: 1.95 },
    BG: { petrol: 1.38, diesel: 1.42 },
    HR: { petrol: 1.55, diesel: 1.60 },
    CY: { petrol: 1.52, diesel: 1.58 },
    CZ: { petrol: 1.55, diesel: 1.62 },
    DK: { petrol: 2.05, diesel: 1.85 },
    EE: { petrol: 1.62, diesel: 1.68 },
    FI: { petrol: 1.95, diesel: 1.88 },
    FR: { petrol: 1.89, diesel: 1.92 },
    DE: { petrol: 1.85, diesel: 1.80 },
    GR: { petrol: 1.82, diesel: 1.68 },
    HU: { petrol: 1.58, diesel: 1.65 },
    IE: { petrol: 1.85, diesel: 1.78 },
    IT: { petrol: 1.92, diesel: 1.85 },
    LV: { petrol: 1.60, diesel: 1.65 },
    LT: { petrol: 1.55, diesel: 1.58 },
    LU: { petrol: 1.58, diesel: 1.52 },
    MT: { petrol: 1.34, diesel: 1.21 },
    NL: { petrol: 2.35, diesel: 2.48 },
    PL: { petrol: 1.52, diesel: 1.58 },
    PT: { petrol: 1.82, diesel: 1.72 },
    RO: { petrol: 1.48, diesel: 1.55 },
    SK: { petrol: 1.62, diesel: 1.52 },
    SI: { petrol: 1.58, diesel: 1.62 },
    ES: { petrol: 1.65, diesel: 1.58 },
    SE: { petrol: 1.92, diesel: 2.02 },
  };

  const countries: CountryPriceData[] = EU27_CODES.map(code => ({
    countryCode: code,
    countryName: COUNTRIES[code].name,
    petrolPrice: seedPrices[code]?.petrol ?? null,
    dieselPrice: seedPrices[code]?.diesel ?? null,
    petrolChangePct: (Math.random() * 6 - 2), // Random -2% to +4% for seed
    dieselChangePct: (Math.random() * 6 - 2),
  }));

  const avgPetrol = countries.reduce((s, c) => s + (c.petrolPrice || 0), 0) / countries.length;
  const avgDiesel = countries.reduce((s, c) => s + (c.dieselPrice || 0), 0) / countries.length;

  return {
    lastUpdated: new Date().toISOString(),
    bulletinDate: new Date().toISOString().split('T')[0],
    dataSource: 'SEED DATA — EC Weekly Oil Bulletin (approximate)',
    countries,
    euAverage: {
      petrolPrice: Math.round(avgPetrol * 1000) / 1000,
      dieselPrice: Math.round(avgDiesel * 1000) / 1000,
    },
  };
}

// ─── Main ────────────────────────────────────────────────

async function main() {
  console.log('⛽ EuroOilWatch — Fetching Fuel Prices');
  console.log('======================================');

  // Try sources in order of preference
  let dataset = await fetchEurostatPrices();

  if (!dataset) {
    dataset = await fetchOilBulletinDirect();
  }

  if (!dataset) {
    console.log('\n⚠️  Could not fetch live price data. Using seed data.');
    console.log('    This is fine for development — the pipeline will be refined');
    console.log('    once you confirm the exact data format from the Oil Bulletin.');
    dataset = generateSeedPrices();
  }

  // Write output
  const outputDir = path.dirname(OUTPUT_FILE);
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(dataset, null, 2));

  console.log(`\n✅ Written to ${OUTPUT_FILE}`);
  console.log(`   Countries: ${dataset.countries.length}`);
  console.log(`   EU avg petrol: €${dataset.euAverage.petrolPrice}/L`);
  console.log(`   EU avg diesel: €${dataset.euAverage.dieselPrice}/L`);
}

main().catch(err => {
  console.error('❌ Fatal error:', err.message);
  process.exit(1);
});
