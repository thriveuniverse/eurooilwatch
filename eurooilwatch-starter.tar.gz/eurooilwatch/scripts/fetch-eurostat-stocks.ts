#!/usr/bin/env npx tsx
/**
 * EuroOilWatch — Eurostat Oil Stocks Fetcher
 * ============================================
 * Pulls monthly oil stock levels from Eurostat API (nrg_stk_oilm)
 * and consumption data from (nrg_cb_oilm) to calculate days-of-supply.
 *
 * Usage: npx tsx scripts/fetch-eurostat-stocks.ts
 * Output: data/stocks.json
 *
 * Eurostat API docs:
 * https://ec.europa.eu/eurostat/web/user-guides/data-browser/api-data-access
 */

import * as fs from 'fs';
import * as path from 'path';
import {
  EurostatResponse,
  FuelType,
  FuelStock,
  CountryStockData,
  StockDataset,
  ReserveStatus,
  ExtendedCountryCode,
} from '../lib/types';
import {
  COUNTRIES,
  EU27_CODES,
  FUEL_SIEC_CODES,
  fromEurostatGeo,
} from '../lib/countries';

// ─── Config ───────────────────────────────────────────────
const BASE_URL = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data';
const OUTPUT_FILE = path.join(__dirname, '..', 'data', 'stocks.json');

/**
 * EU mandatory minimum: 90 days of net imports or 61 days of consumption,
 * whichever is higher. We use 90 as the reference since most countries
 * are net importers.
 */
const MANDATORY_MINIMUM_DAYS = 90;

/** Status thresholds (as ratio of mandatory minimum) */
const STATUS_THRESHOLDS = {
  safe: 1.1,      // >110% of minimum = safe
  watch: 0.95,    // 95-110% = watch
  warning: 0.85,  // 85-95% = warning
  // below 85% = critical
};

// ─── Helpers ──────────────────────────────────────────────

function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Fetch a Eurostat dataset with retry logic.
 */
async function fetchEurostat(
  dataset: string,
  params: Record<string, string | string[]>
): Promise<EurostatResponse> {
  const url = new URL(`${BASE_URL}/${dataset}`);
  url.searchParams.set('format', 'JSON');
  url.searchParams.set('lang', 'en');

  for (const [key, value] of Object.entries(params)) {
    if (Array.isArray(value)) {
      value.forEach(v => url.searchParams.append(key, v));
    } else {
      url.searchParams.set(key, value);
    }
  }

  console.log(`  Fetching: ${dataset}`);
  console.log(`  URL: ${url.toString().substring(0, 120)}...`);

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await fetch(url.toString(), {
        headers: { 'User-Agent': 'EuroOilWatch/0.1 (data-pipeline)' },
      });

      if (response.status === 413) {
        // Async response — Eurostat is processing, retry after delay
        console.log(`  ⏳ Eurostat processing (attempt ${attempt}/3), waiting 30s...`);
        await sleep(30000);
        continue;
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json() as EurostatResponse;
      console.log(`  ✅ Got ${Object.keys(data.value || {}).length} data points`);
      return data;
    } catch (error: any) {
      console.log(`  ⚠️ Attempt ${attempt} failed: ${error.message}`);
      if (attempt < 3) await sleep(5000);
      else throw error;
    }
  }

  throw new Error(`Failed after 3 attempts for ${dataset}`);
}

/**
 * Parse Eurostat multi-dimensional JSON into a flat lookup.
 * Returns: Map<"geo|siec|time", value>
 */
function parseEurostatValues(
  data: EurostatResponse
): Map<string, number> {
  const result = new Map<string, number>();
  const dims = data.id; // e.g. ['freq', 'stk_flow', 'siec', 'geo', 'time']
  const sizes = data.size;

  // Build index → label maps for each dimension
  const dimIndices: Record<string, string>[] = dims.map(dimName => {
    const cat = data.dimension[dimName]?.category;
    if (!cat) return {};
    const indexMap: Record<string, string> = {};
    for (const [code, idx] of Object.entries(cat.index)) {
      indexMap[String(idx)] = code;
    }
    return indexMap;
  });

  // Iterate over flat values and reconstruct dimension coordinates
  for (const [flatIndex, value] of Object.entries(data.value)) {
    const idx = parseInt(flatIndex);
    const coords: string[] = [];

    let remaining = idx;
    for (let d = dims.length - 1; d >= 0; d--) {
      const dimSize = sizes[d];
      const posInDim = remaining % dimSize;
      remaining = Math.floor(remaining / dimSize);
      const code = dimIndices[d][String(posInDim)] || String(posInDim);
      coords.unshift(code);
    }

    // Create key from geo, siec, time (skip freq and stk_flow)
    const geoIdx = dims.indexOf('geo');
    const siecIdx = dims.indexOf('siec');
    const timeIdx = dims.indexOf('time');

    const geo = geoIdx >= 0 ? coords[geoIdx] : '';
    const siec = siecIdx >= 0 ? coords[siecIdx] : '';
    const time = timeIdx >= 0 ? coords[timeIdx] : '';

    const key = `${geo}|${siec}|${time}`;
    result.set(key, value);
  }

  return result;
}

/**
 * Get the latest available time period from a Eurostat response.
 */
function getLatestTimePeriod(data: EurostatResponse): string {
  const timeDim = data.dimension?.time?.category?.index;
  if (!timeDim) return 'unknown';
  const periods = Object.keys(timeDim).sort();
  return periods[periods.length - 1] || 'unknown';
}

/**
 * Calculate reserve status based on days of supply vs mandatory minimum.
 */
function getStatus(daysOfSupply: number, minimum: number): ReserveStatus {
  const ratio = daysOfSupply / minimum;
  if (ratio >= STATUS_THRESHOLDS.safe) return 'safe';
  if (ratio >= STATUS_THRESHOLDS.watch) return 'watch';
  if (ratio >= STATUS_THRESHOLDS.warning) return 'warning';
  return 'critical';
}

// ─── Main ────────────────────────────────────────────────

async function main() {
  console.log('🛢️  EuroOilWatch — Fetching Oil Stock Data');
  console.log('==========================================');

  const allEurostatCodes = EU27_CODES.map(
    c => COUNTRIES[c].eurostatCode
  );
  const fuelCodes = Object.values(FUEL_SIEC_CODES);

  // ─── 1. Fetch stock levels ───
  console.log('\n📦 Step 1: Fetching stock levels (nrg_stk_oilm)...');
  const stocksData = await fetchEurostat('nrg_stk_oilm', {
    siec: fuelCodes,
    geo: allEurostatCodes,
    stk_flow: 'STKCL_NAT', // Closing stock on national territory
    lastTimePeriod: '6',    // Last 6 months available
  });
  const stockValues = parseEurostatValues(stocksData);
  const latestStockPeriod = getLatestTimePeriod(stocksData);

  // ─── 2. Fetch consumption data ───
  console.log('\n📊 Step 2: Fetching consumption data (nrg_cb_oilm)...');
  let consumptionValues: Map<string, number>;
  let consumptionAvailable = true;

  try {
    const consumptionData = await fetchEurostat('nrg_cb_oilm', {
      siec: fuelCodes,
      geo: allEurostatCodes,
      nrg_bal: 'GIC',         // Gross Inland Consumption
      lastTimePeriod: '6',
    });
    consumptionValues = parseEurostatValues(consumptionData);
  } catch (err: any) {
    console.log(`  ⚠️  Consumption data unavailable: ${err.message}`);
    console.log('  Using fallback estimation (stock / 3 months)');
    consumptionAvailable = false;
    consumptionValues = new Map();
  }

  // ─── 3. Build country-level data ───
  console.log('\n🔧 Step 3: Building country datasets...');

  const countries: CountryStockData[] = [];
  let totalPetrolDays = 0, totalDieselDays = 0, totalJetDays = 0;
  let countPetrol = 0, countDiesel = 0, countJet = 0;

  for (const code of EU27_CODES) {
    const country = COUNTRIES[code];
    const geoCode = country.eurostatCode;
    const fuels: FuelStock[] = [];

    for (const [fuelKey, siecCode] of Object.entries(FUEL_SIEC_CODES)) {
      const fuelType = fuelKey as FuelType;

      // Find stock value for latest period
      const stockKey = `${geoCode}|${siecCode}|${latestStockPeriod}`;
      const stockTonnes = stockValues.get(stockKey);

      // Find consumption value
      let consumptionTonnes: number | undefined;
      if (consumptionAvailable) {
        const consKey = `${geoCode}|${siecCode}|${latestStockPeriod}`;
        consumptionTonnes = consumptionValues.get(consKey);

        // Try previous months if current not available
        if (!consumptionTonnes) {
          const period = latestStockPeriod.split('-');
          const year = parseInt(period[0]);
          const month = parseInt(period[1]);
          for (let i = 1; i <= 3; i++) {
            let m = month - i;
            let y = year;
            if (m <= 0) { m += 12; y -= 1; }
            const prevKey = `${geoCode}|${siecCode}|${y}-${String(m).padStart(2, '0')}`;
            consumptionTonnes = consumptionValues.get(prevKey);
            if (consumptionTonnes) break;
          }
        }
      }

      if (stockTonnes !== undefined) {
        let daysOfSupply: number;

        if (consumptionTonnes && consumptionTonnes > 0) {
          // Stock (thousand tonnes) / monthly consumption (thousand tonnes) * 30 days
          daysOfSupply = (stockTonnes / consumptionTonnes) * 30;
        } else {
          // Rough fallback: assume stock covers ~3 months
          // (will be replaced once consumption data is available)
          daysOfSupply = 90; // Default assumption
          console.log(`    ⚠️ No consumption data for ${geoCode}/${fuelType}, using fallback`);
        }

        const status = getStatus(daysOfSupply, MANDATORY_MINIMUM_DAYS);

        fuels.push({
          fuelType,
          stockKilotonnes: stockTonnes,
          consumptionKilotonnes: consumptionTonnes || 0,
          daysOfSupply: Math.round(daysOfSupply * 10) / 10,
          mandatoryMinimumDays: MANDATORY_MINIMUM_DAYS,
          status,
        });

        // Accumulate for EU average
        if (fuelType === 'petrol') { totalPetrolDays += daysOfSupply; countPetrol++; }
        if (fuelType === 'diesel') { totalDieselDays += daysOfSupply; countDiesel++; }
        if (fuelType === 'jet_fuel') { totalJetDays += daysOfSupply; countJet++; }

        console.log(`  ${country.flag} ${country.name} — ${fuelType}: ${daysOfSupply.toFixed(1)} days [${status}]`);
      } else {
        console.log(`  ${country.flag} ${country.name} — ${fuelType}: no data`);
      }
    }

    if (fuels.length > 0) {
      const avgDays = fuels.reduce((sum, f) => sum + f.daysOfSupply, 0) / fuels.length;
      const worstStatus = fuels.reduce<ReserveStatus>((worst, f) => {
        const order: ReserveStatus[] = ['critical', 'warning', 'watch', 'safe'];
        return order.indexOf(f.status) < order.indexOf(worst) ? f.status : worst;
      }, 'safe');

      countries.push({
        countryCode: code,
        countryName: country.name,
        datePeriod: latestStockPeriod,
        fuels,
        averageDays: Math.round(avgDays * 10) / 10,
        overallStatus: worstStatus,
      });
    }
  }

  // ─── 4. Calculate EU averages ───
  const euPetrolDays = countPetrol > 0 ? totalPetrolDays / countPetrol : 0;
  const euDieselDays = countDiesel > 0 ? totalDieselDays / countDiesel : 0;
  const euJetDays = countJet > 0 ? totalJetDays / countJet : 0;
  const euOverallDays = (euPetrolDays + euDieselDays + euJetDays) / 3;
  const euStatus = getStatus(euOverallDays, MANDATORY_MINIMUM_DAYS);

  // ─── 5. Write output ───
  const dataset: StockDataset = {
    lastUpdated: new Date().toISOString(),
    dataPeriod: latestStockPeriod,
    dataSource: 'Eurostat nrg_stk_oilm / nrg_cb_oilm',
    countries: countries.sort((a, b) => a.averageDays - b.averageDays), // lowest first
    euAverage: {
      petrolDays: Math.round(euPetrolDays * 10) / 10,
      dieselDays: Math.round(euDieselDays * 10) / 10,
      jetFuelDays: Math.round(euJetDays * 10) / 10,
      overallStatus: euStatus,
    },
  };

  const outputDir = path.dirname(OUTPUT_FILE);
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(dataset, null, 2));

  console.log('\n' + '═'.repeat(50));
  console.log('📊 Summary');
  console.log('═'.repeat(50));
  console.log(`Countries with data: ${countries.length}/27`);
  console.log(`Data period: ${latestStockPeriod}`);
  console.log(`EU avg petrol: ${euPetrolDays.toFixed(1)} days`);
  console.log(`EU avg diesel: ${euDieselDays.toFixed(1)} days`);
  console.log(`EU avg jet fuel: ${euJetDays.toFixed(1)} days`);
  console.log(`EU status: ${euStatus}`);
  console.log(`\nOutput: ${OUTPUT_FILE}`);
}

main().catch(err => {
  console.error('❌ Fatal error:', err.message);
  process.exit(1);
});
